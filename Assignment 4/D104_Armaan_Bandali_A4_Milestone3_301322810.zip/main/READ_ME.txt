Milestone 3:

-All game logic implemented for level one and two
-Full image based graphics for level one and two
-Level one, two, and three are fully playable, with scores, and gameovers
-Not all of the concepts(inclusion polymorphism, overloading, etc.) have been implemented in the code yet

New concepts:
-addition of gopher obstacle in mowing game
-addition of sound effects in trash game on successful throw
-increased difficulty of trash game by varying can height

References:
-trashBin image: https://pixabay.com/vectors/delete-dustbin-garbage-can-1727486/
-trashBag image: https://pixabay.com/illustrations/bag-trash-waste-garbage-housewives-1010758/
-dog image: https://pixabay.com/illustrations/dog-animals-pet-bull-terrier-1454220/
-gopher image: https://pixabay.com/vectors/groundhog-animal-winter-rodent-153207/
-hallway lawnmower image: https://pixabay.com/vectors/lawnmower-lawn-mower-lawn-mower-155231/
-bg music: https://soundimage.org/funnyquirky/
-trash sound effect: https://freesound.org/people/Porklash/sounds/485580/

-all original images drawn using Gimp on April 10, 2021