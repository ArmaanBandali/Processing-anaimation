Milestone 2:

-All game logic implemented for level one and two
-Level one and two are fully playable, with scores, and gameovers
-No drawn images or sounds have been implemented yet
-Not all of the concepts(inclusion polymorphism, overloading, etc.) have been implemented in the code yet
-Milestone 1 was not submitted, so all concepts are new :)