ECO Points:

- complex, unique animations with bosses, enemies, and player
- Difficulty increase: enemies move faster the longer they stay alive
- Enemies have a 20% chance of spawning with a shield, blocking one damage
- Start and End screens have flavour text
- Health boost item
- Different weapons with super bullets
- Collectable player shield
- Achievement 1: survive 10 seconds without taking damage
- Achievement 2: kill 10 enemies without taking damage